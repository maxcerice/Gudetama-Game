class Mage:
    pass
