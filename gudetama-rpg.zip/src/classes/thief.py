class Thief:
    pass
