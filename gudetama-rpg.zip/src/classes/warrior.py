class Warrior:
    pass
