class Archer:
    pass
